package com.example.gymgo

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class EquipmentAdapter(private val equipmentList: List<EquipmentItem>, private val listener: OnAddButtonClickListener) :
    RecyclerView.Adapter<EquipmentAdapter.EquipmentViewHolder>() {

    interface OnAddButtonClickListener {
        fun onAddButtonClick(workoutName: String)
    }

    class EquipmentViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val imageView: ImageView = view.findViewById(R.id.equipmentImage)
        val textView: TextView = view.findViewById(R.id.workoutName)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EquipmentViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.equipment_item, parent, false)
        return EquipmentViewHolder(view)
    }

    override fun onBindViewHolder(holder: EquipmentViewHolder, position: Int) {
        val item = equipmentList[position]
        holder.imageView.setImageResource(item.imageResource)
        holder.textView.text = item.workoutName
//        holder.addButton.setOnClickListener {
//            listener.onAddButtonClick(item.workoutName)
//        }
    }

    override fun getItemCount() = equipmentList.size
}
