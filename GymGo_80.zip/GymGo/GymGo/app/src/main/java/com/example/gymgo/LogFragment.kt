package com.example.gymgo

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.LinearLayoutManager
import android.widget.Toast


class LogFragment : Fragment(), EquipmentAdapter.OnAddButtonClickListener {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_log, container, false)
        val recyclerView = view.findViewById<RecyclerView>(R.id.equipmentRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(context)

        // Create a list of EquipmentItem objects
        val equipmentItems = listOf(
            EquipmentItem(R.drawable.treadmill, "Treadmill Workout"),
            EquipmentItem(R.drawable.bike, "Bike Session"),
            EquipmentItem(R.drawable.barbells, "Barbell Lifts"),
            EquipmentItem(R.drawable.chestpress, "Chest Press"),
            EquipmentItem(R.drawable.latpulldown, "Lat PullDown"),
            EquipmentItem(R.drawable.kettlebells, "Kettle bells"),
            EquipmentItem(R.drawable.barbells, "Barbells")

        )

        recyclerView.adapter = EquipmentAdapter(equipmentItems, this)
        return view
    }

    override fun onAddButtonClick(workoutName: String) {
        // Handle navigation here, potentially passing the workoutName to the new fragment or activity
        Toast.makeText(context, "Add details for $workoutName", Toast.LENGTH_SHORT).show()
    }
}
