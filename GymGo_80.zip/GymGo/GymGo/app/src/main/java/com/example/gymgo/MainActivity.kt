package com.example.gymgo

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.Spinner
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.AutoCompleteTextView
import android.content.Context
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    // Map of universities to their respective gym options
    private val universityGyms = mapOf(
        "University of Pittsburgh" to listOf(
            "Baierl Student Rec Center",
            "Trees Hall Fitness Center",
            "William Pitt Union Fitness Center",
            "Bellefield Hall Fitness Center",
            "Towers Fitness Center"
        )
        // Add more universities and their gyms here
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val autoCompleteUniversity: AutoCompleteTextView = findViewById(R.id.autoCompleteUniversity)
        val spinnerGyms: Spinner = findViewById(R.id.spinner2)
        val usernameEditText: EditText = findViewById(R.id.editTextText)
        val passwordEditText: EditText = findViewById(R.id.editTextTextPassword)
        val registerButton: Button = findViewById(R.id.button)
        val loginButton: Button = findViewById(R.id.button2)

        // Setting up AutoComplete for universities
        val universityAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_dropdown_item_1line,
            universityGyms.keys.toList()
        )
        autoCompleteUniversity.setAdapter(universityAdapter)
        autoCompleteUniversity.threshold = 1

        // AutoComplete item selection listener to update gym spinner
        autoCompleteUniversity.setOnItemClickListener { parent, _, position, _ ->
            val selectedUniversity = parent.getItemAtPosition(position) as String
            updateGymsSpinner(selectedUniversity, spinnerGyms)
        }

        // Registration button functionality
        registerButton.setOnClickListener {
            val username = usernameEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()
            if (username.isNotEmpty() && password.isNotEmpty()) {
                val editor = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE).edit()
                editor.putString("username", username)
                editor.putString("password", password)
                editor.apply()
                Toast.makeText(this, "Registration successful", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Please enter both username and password", Toast.LENGTH_SHORT).show()
            }
        }

        // Login button functionality
        loginButton.setOnClickListener {
            val username = usernameEditText.text.toString().trim()
            val password = passwordEditText.text.toString().trim()
            val prefs = getSharedPreferences("UserPrefs", Context.MODE_PRIVATE)
            val storedUsername = prefs.getString("username", null)
            val storedPassword = prefs.getString("password", null)
            if (username == storedUsername && password == storedPassword) {
                val intent = Intent(this, HomeActivity::class.java)
                intent.putExtra("username", username)  // Pass the username to HomeActivity
                startActivity(intent)
                Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show()
            }
        }

    }

    private fun updateGymsSpinner(university: String, spinner: Spinner) {
        val gyms = universityGyms[university] ?: listOf()
        setupSpinner(spinner, gyms)
    }

    private fun setupSpinner(spinner: Spinner, items: List<String>) {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, items)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter
    }
}
