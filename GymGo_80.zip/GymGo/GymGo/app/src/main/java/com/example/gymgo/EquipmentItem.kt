package com.example.gymgo

data class EquipmentItem(val imageResource: Int, val workoutName: String)
